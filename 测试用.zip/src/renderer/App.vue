<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<script>

export default {
    name: "epicasa",
};

</script>

<style>
/* CSS */
* {
    margin: 0;
    padding: 0;
}
</style>
