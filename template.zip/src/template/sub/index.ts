// 引入 View 层
import 'src/view/container/sub/index';

console.log('%cThis is Sub Index', 'color: blue; font-size: 16px;');
