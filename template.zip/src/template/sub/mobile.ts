// 引入 View 层
import 'src/view/container/sub/mobile';

console.log('%cThis is Sub Mobile', 'color: blue; font-size: 16px;');
