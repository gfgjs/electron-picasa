// 引入 View 层
import 'src/view/container/mobile';

console.log('%cThis is Mobile', 'color: blue; font-size: 16px;');
