console.log('store');

export default {};
