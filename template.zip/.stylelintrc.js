module.exports = 
{
    "extends": "stylelint-config-standard",
    "rules": {
        // style 文件也是 4 格缩进
        "indentation": 4
    }
}
